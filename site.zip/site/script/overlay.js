function openOverlay(id) {
    document.getElementById('overlay' + id).style.display = 'block';
}

function closeOverlay(id) {
    document.getElementById('overlay' + id).style.display = 'none';
}
