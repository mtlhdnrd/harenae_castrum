<?php
    require_once "database.php";
    echo get_planets();
